#ifndef VEHICULE_H_INCLUDED
#define VEHICULE_H_INCLUDED
#include <string>
#include <iostream>
class Vehicule
{
    public:
   Vehicule(int nbRoues,int vitesse,int prix);
   virtual void affiche() const;  //Affiche une description du Vehicule
   virtual ~Vehicule();
   virtual void getNbRoues()const=0;
    protected:
    int m_prix;  //Chaque v�hicule a un prix
    double m_vitesse;  //La vitesse max d'un Vehicule
    int m_nbRoues;
};

class Voiture : public Vehicule //Une Voiture EST UN Vehicule
{
    public:
    Voiture(int nbRoues,int vitesse,int prix,int nbPortes);
    //virtual pas obligatoire puisqu'il y a heritage
   virtual  void affiche() const;
    virtual ~Voiture();
   virtual void getNbRoues()const;
    private:
    int m_portes;  //Le nombre de portes d'un v�hicule
};

class Moto : public Vehicule  //Une Moto EST UN Vehicule
{
    public:
    Moto(int nbRoues,int vitesse,int prix);
         //virtual pas obligatoire puisqu'il y a heritage
   virtual void affiche() const;
   virtual ~Moto();
   virtual void getNbRoues()const;
    private:

};

#endif // VEHICULE_H_INCLUDED
