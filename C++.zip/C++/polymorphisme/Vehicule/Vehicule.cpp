#include "Vehicule.h"
#include <iostream>
#include <string>
//to do
//corriger les warnings
//correct the warnings
using namespace std;

Vehicule::Vehicule(int nbRoues,int vitesse,int prix): m_vitesse(vitesse),m_nbRoues(nbRoues),m_prix(prix){}
void Vehicule::affiche() const{
    cout << "Ceci est un vehicule." << endl;
}
Vehicule::~Vehicule(){}

Voiture::Voiture(int nbRoues,int vitesse,int prix,int nbPortes):Vehicule(nbRoues,vitesse,prix),m_portes(nbPortes){}
void Voiture::affiche() const{
    cout << "Ceci est une voiture." << endl;
}
Voiture::~Voiture(){}

void Voiture::getNbRoues()const{
        cout << "cette voiture a " <<  m_nbRoues << endl;

}

Moto::Moto(int nbRoues,int vitesse,int prix): Vehicule(nbRoues,vitesse,prix){}
void Moto::affiche() const{
    cout << "Ceci est une moto." << endl;
}


Moto::~Moto(){}
void Moto::getNbRoues()const{
        cout << "cette moto � "<<m_nbRoues << endl;
}
