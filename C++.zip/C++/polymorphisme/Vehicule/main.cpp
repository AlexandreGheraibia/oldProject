#include <iostream>
#include <string>

#include "Vehicule.h"
#include <vector>
using namespace std;
/*exemple polymorphique
pour le polymorphisme,passe par la r�solution de lien dynamique (d�terminer la anature de l'objet en param�tre),
 il faut un pointeur ou une r�f�rence et une m�thode virtuelle.
une classe abstraite est une classe qui a une m�thode virtuelle pure.
Ce qui veut dire que la m�thode est d�clar�e virtuelle est n'a pas d'implementation dans la classe
elle est initialis�e � 0 dans la d�claration de son prototype.

*/
void presenter(Vehicule const &V){
    V.affiche();
}
int main()
{//    Vehicule v;     /*declare un objet Vehicule*/
//    presenter(v);    //Affiche "Ceci est un vehicule." fonction de la classe m�re

//    Moto m;         /*declare un objet moto*/
//    presenter(m);    //Affiche "Ceci est une moto." fonction surcharger de la classe fille
    Vehicule *V1(0),*V2(0);//d�claration de 2 pointeurs initialis� � null
    V1=new Voiture(4,220,2500,4);
    V2=new Moto(2,300,2000);
    //presenter(*V1);
    presenter(*V2);
    V1->affiche();
    V2->affiche();
    delete V1;
    delete V2;
    vector <Vehicule *> garage;
    garage.push_back(new Voiture(4,220,2500,4));
    garage.push_back(new Moto(2,300,2000));
    garage[0]->affiche();
    garage[1]->affiche();
    garage[0]->getNbRoues();
    garage[1]->getNbRoues();
    for(unsigned int i=0;i<garage.size();i++){
        delete garage[i];
        garage[i]=0;
    }
    return 0;
}
