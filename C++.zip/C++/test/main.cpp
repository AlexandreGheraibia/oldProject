#include <iostream>
#include <string>
using namespace std;

int main()
{
    double nombreA(0.0),nombreB(0.0);
    cout<<"Entrer le premier nombre de l'addition"<<endl;
    cin>>nombreA;
    cout<<"Entrer le second nombre de l'addition"<<endl;
    cin>>nombreB;
    double const resultat(nombreA+nombreB);
    cout<<"l'addition de "<<nombreA<<" et de "<<nombreB<<" est: "<<resultat<<endl;
    return 0;

}
