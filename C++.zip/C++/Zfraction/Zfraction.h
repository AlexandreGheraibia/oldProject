#ifndef ZFRACTION_H_INCLUDED
#define ZFRACTION_H_INCLUDED
#include <iostream>

class zFraction{
    private:
        int m_numerateur;
        int m_denominateur;
    public:
        zFraction();
        zFraction(int numerateur,int denominateur=1);
        zFraction(zFraction const & fraction);
        void afficher(std::ostream & flux) const;
        void affecter(std::istream &flux);
        bool egalFraction(zFraction const & b)const;
        bool estSup(zFraction const &b)const;
        zFraction & operator+=(zFraction const &b);
        zFraction & operator-=(zFraction const &b);
        zFraction & operator*=(zFraction const &b);
        zFraction & operator/=(zFraction const &b);
};

int pgcd(int first,int second);
std::ostream &operator <<(std::ostream & flux,zFraction const & fraction);
std::istream &operator >>(std::istream & flux,zFraction & fraction);
zFraction operator+(zFraction const & a,zFraction const & b);
zFraction operator-(zFraction const & a,zFraction const & b);
zFraction operator*(zFraction const & a,zFraction const & b);
zFraction operator/(zFraction const & a,zFraction const & b);
//zFraction operator%(zFraction const & a,zFraction const & b);
bool operator==(zFraction const & a,zFraction const & b);
bool operator!=(zFraction const & a,zFraction const & b);
bool operator>(zFraction const & a,zFraction const & b);
bool operator<(zFraction const & a,zFraction const & b);
bool operator<=(zFraction const & a,zFraction const & b);
bool operator>=(zFraction const & a,zFraction const & b);

#endif // ZFRACTION_H_INCLUDED
