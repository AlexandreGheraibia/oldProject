#include "zfraction.h"

#include <string>
#include <iostream>

using namespace std;

zFraction::zFraction():m_numerateur(0),m_denominateur(1){};
zFraction::zFraction(int numerateur,int denominateur): m_numerateur(numerateur){
    if(denominateur!=0){
                m_numerateur=pgcd(numerateur,denominateur);
                m_denominateur=denominateur/m_numerateur;
                m_numerateur=numerateur/m_numerateur;
   }
    else{
        cout <<"un nombre rationnel ne peut avoir un denominateur nul"<<endl;
    }
}
zFraction::zFraction(zFraction const & fraction){
        m_numerateur=fraction.m_numerateur;
        m_denominateur=fraction.m_denominateur;
}

void zFraction::afficher(ostream & flux) const{
    flux <<m_numerateur<<"/"<< m_denominateur;
}
void zFraction::affecter(istream &flux){
    int tmp;
    flux>>m_numerateur;
    flux>>m_denominateur;
    tmp=pgcd(m_numerateur,m_denominateur);
    m_numerateur/=tmp;
    m_denominateur/=tmp;
}
bool zFraction::egalFraction(zFraction const &b)const{
    return ((m_numerateur/(double)m_denominateur)==(b.m_numerateur/(double)b.m_denominateur));
}
bool zFraction::estSup(zFraction const &b)const{
    return ((m_numerateur/(double)m_denominateur)>(b.m_numerateur/(double)b.m_denominateur));
}

zFraction &zFraction::operator+=(zFraction const&b){
    int tmp;
    m_numerateur=m_numerateur*b.m_denominateur+b.m_numerateur*m_denominateur;
    m_denominateur*=b.m_denominateur;
    tmp=pgcd(m_numerateur,m_denominateur);
    m_numerateur/=tmp;
    m_denominateur/=tmp;
    return *this;
}
zFraction &zFraction::operator-=(zFraction const&b){
    int tmp;
    m_numerateur=m_numerateur*b.m_denominateur-b.m_numerateur*m_denominateur;
    m_denominateur*=b.m_denominateur;
    tmp=pgcd(m_numerateur,m_denominateur);
    m_numerateur/=tmp;
    m_denominateur/=tmp;
    return *this;
}
zFraction &zFraction::operator*=(zFraction const&b){
    int tmp;
    m_numerateur=m_numerateur*b.m_numerateur;
    m_denominateur*=b.m_denominateur;
    tmp=pgcd(m_numerateur,m_denominateur);
    m_numerateur/=tmp;
    m_denominateur/=tmp;
    return *this;
}
zFraction &zFraction::operator/=(zFraction const&b){
    int tmp;
    m_numerateur=m_numerateur/b.m_denominateur;
    m_denominateur*=b.m_numerateur;
    tmp=pgcd(m_numerateur,m_denominateur);
    m_numerateur/=tmp;
    m_denominateur/=tmp;
    return *this;
}
zFraction operator+(zFraction const &a,zFraction const &b){
    zFraction tmp;
    tmp=a;
    tmp+=b;
    return tmp;
}
zFraction operator-(zFraction const &a,zFraction const &b){
    zFraction tmp;
    tmp=a;
    tmp-=b;
    return tmp;
}
zFraction operator*(zFraction const & a,zFraction const & b){
    zFraction tmp;
    tmp=a;
    tmp*=b;
    return tmp;
}
zFraction operator/(zFraction const & a,zFraction const & b){
     zFraction tmp;
    tmp=a;
    tmp/=b;
    return tmp;
}



int pgcd(int first,int second){
    int b(second),a(first),t;
    while(b!=0){
        t=b;
        b=a%b;
        a=t;
    }
    return a;
}

ostream &operator <<(ostream & flux,zFraction const & fraction){
        fraction.afficher(flux);
        return flux;
}
istream &operator >>(istream & flux,zFraction & fraction){
        fraction.affecter(flux);
        return flux;
}

bool operator==(zFraction const & a,zFraction const & b){
    return a.egalFraction(b);
}
bool operator!=(zFraction const & a,zFraction const & b){
    return !(a==b);
}
bool operator>(zFraction const & a,zFraction const & b){
    return a.estSup(b);
}
bool operator<(zFraction const & a,zFraction const & b){
    return (b>a);
}
bool operator<=(zFraction const & a,zFraction const & b){
    return !(a>b);
}
bool operator>=(zFraction const & a,zFraction const & b){
    return !(a<b);
}

