#ifndef ARME_H_INCLUDED
#define ARME_H_INCLUDED
#include <string>
class Arme{
    private:
    std::string m_nom;
    int m_degats;
    public:
        Arme();
        Arme(std::string nomArme,int degatsArme);
        Arme(Arme const &autre);
        void changerArme(std::string nom,int nbDegats);
        int getDegats() const;
        std::string getArme() const;
        void afficher() const;
};

#endif // ARME_H_INCLUDED
