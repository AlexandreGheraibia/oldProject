#ifndef PERSONNAGE_H_INCLUDED
#define PERSONNAGE_H_INCLUDED
#include <string>
#include "Arme.h"
/*Prototype de la classe personnage
*/
class Personnage{


 protected:
     std::string m_name;
     int m_vie;
     int m_mana;
     int m_level;
     Arme *m_monArme;

     //int m_degatsArme;
     //std::string m_nomArme;

public:
    /*d�finition du constructeur par d�faut*/
    Personnage();
    Personnage(std::string name);
    /*Surcharge du constructeur Personnage*/
    Personnage( std::string name,std::string nomArme,int nbDegats);
    /*Surcharge du constructeur de copie de Personnage*/
    Personnage(Personnage const& autre);
    /*definition du destructeur par d�faut*/
    ~Personnage();

    void recevoirDegats(int nbDegats);
    void attaquer(Personnage& cible)const;
    void boirePotionDeVie(int quantitePotion);
    void changerArme(std::string nomArme,int degatsNvellArme);
    void changerName(std::string namre);
    bool estVivant() const;
    std::string getName() const;
    void levelUp(int nbDelevelAjoute);
    void afficherEtat() const;
    Personnage& operator=(Personnage const& personnageACopier);
};


#endif // PERSONNAGE_H_INCLUDED
