#ifndef GUERRIER_H_INCLUDED
#define GUERRIER_H_INCLUDED
#include "Personnage.h"
#include "Arme.h"
#include <iostream>
#include <string>


class guerrier: public Personnage{


    public :
    guerrier();
    guerrier(std::string name);
    guerrier(std::string name,std::string nomArme,int nbDegats);

    void afficherEtat() const;
    void attaqueSpecial(Personnage& cible)const;



};

#endif // GUERRIER_H_INCLUDED
