#include "guerrier.h"
#include <iostream>
#include <string>
#include <iostream>
using namespace std;
guerrier::guerrier():Personnage(){}
guerrier::guerrier(string name,string nomArme,int nbDegats):Personnage(name,nomArme,nbDegats){
}
guerrier::guerrier(string name):Personnage(name){}
void guerrier::afficherEtat() const{
    Personnage::afficherEtat();
    cout <<"par thor "<<endl;
}
void guerrier::attaqueSpecial(Personnage& cible)const{
    cout << m_name << " declenche attaque Special contre" << cible.getName() << " avec "<< m_monArme->getArme() << " et lui inflige " << m_monArme->getDegats()*10 << " de d�gats." <<endl;
    cible.recevoirDegats(m_monArme->getDegats()*10);
}

