#include <iostream>
#include <string>
#include "Personnage.h"
#include "guerrier.h"

using namespace std;

int main()
{
    Personnage david("david"),goliath("col");
    guerrier gladiateur;
    goliath=david;
    goliath.changerName("goliath");
    gladiateur.afficherEtat();
    goliath.afficherEtat();
//    gladiateur.attaquer(goliath);
    david.afficherEtat();
    //Cr�ation de 2 objets de type Personnage : david et goliath
    goliath.attaquer(david);    //goliath attaque david
    david.boirePotionDeVie(20); //david r�cup�re 20 de vie en buvant une potion
    goliath.afficherEtat();
    david.afficherEtat();
    goliath.attaquer(david);    //goliath r�attaque david
    david.attaquer(goliath);    //david contre-attaque... c'est assez clair non ?
    goliath.afficherEtat();
    david.afficherEtat();
    goliath.changerArme("Double hache tranchante v�n�neuse de la mort", 40);
    goliath.attaquer(david);
    goliath.afficherEtat();
    david.afficherEtat();
    gladiateur.attaqueSpecial(goliath);

    return 0;


}
