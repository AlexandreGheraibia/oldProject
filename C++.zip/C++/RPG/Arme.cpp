#include "Arme.h"
#include <iostream>
using namespace std;

Arme::Arme(): m_nom("Ep�e Rouill�e"),m_degats(10){}
Arme::Arme(string nomArme,int degatsArme): m_nom(nomArme),m_degats(degatsArme){}
Arme::Arme(Arme const &autre) : m_nom(autre.m_nom),m_degats(autre.m_degats){}

void Arme::changerArme(std::string nom,int nbDegats){
    m_nom=nom;
    m_degats=nbDegats;
}
int Arme::getDegats() const{
    return m_degats;

}
string Arme::getArme() const{

    return m_nom;
}


void Arme::afficher() const
{

    cout << "Arme : " << m_nom << " (D�g�ts : " << m_degats << ")" << endl;

}
