#include "Personnage.h"
#include <iostream>
#include <string>
using namespace std;
Personnage::Personnage():m_name("persodef"),m_vie(100),m_mana(100),m_level(1),m_monArme(new Arme("aucune",0))
{
}
Personnage::Personnage(string name,string nomArme,int nbDegats) : m_name(name),m_vie(100),m_mana(100),m_level(1),m_monArme(new Arme(nomArme,nbDegats)){}
Personnage::Personnage(string name):m_name(name), m_vie(100),m_mana(100),m_level(1), m_monArme(new Arme("Ep�e rouill�e",10)){}
Personnage::Personnage(Personnage const& autre) : m_name(autre.m_name),m_vie(autre.m_vie),m_mana(autre.m_mana)
{
        m_monArme=new Arme(*(autre.m_monArme));

}

Personnage::~Personnage(){
    delete m_monArme;

}


void Personnage::recevoirDegats(int nbDegats){
    m_vie-=nbDegats;
    if (m_vie<0)
        m_vie=0;

}

void Personnage::attaquer(Personnage& cible)const{
    cout << m_name << " attaque " << cible.getName() << " avec "<< m_monArme->getArme() << " et lui inflige " << m_monArme->getDegats() << " de d�gats." <<endl;
    cible.recevoirDegats(m_monArme->getDegats());
}

void Personnage::boirePotionDeVie(int quantitePotion){
    m_vie+=quantitePotion;
    if (m_vie>100){
        m_vie=100;
    }
}

void Personnage::changerArme(string nomArme,int degatsNvellArme){
    m_monArme->changerArme(nomArme,degatsNvellArme);
    //m_nomArme=nomArme;
   // m_degatsArme=degatsNvellArme;
}
void Personnage::changerName(string name){
    m_name=name;
}
bool Personnage::estVivant()const{
    return m_vie>0;
}

string Personnage::getName()const{
    return m_name;
}
void Personnage::levelUp(int nbDelevelAjoute){
    m_level+=nbDelevelAjoute;
}
Personnage& Personnage::operator=(Personnage const& personnageACopier){
    if(this!=&personnageACopier){
        m_name=personnageACopier.m_name;
        m_vie=personnageACopier.m_vie;
        m_mana=personnageACopier.m_mana;
        m_level=personnageACopier.m_level;
        delete m_monArme;
        m_monArme=new Arme(*(personnageACopier.m_monArme));

    }
    return *this;

}
void Personnage::afficherEtat() const
{   cout <<endl << m_name << endl;
    cout << "Vie : " << m_vie << endl;
    cout << "Mana : " << m_mana << endl;
    m_monArme->afficher();
    cout << endl;
}
