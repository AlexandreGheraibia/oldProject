#include <iostream>
#include "Duree.h"
using namespace std;

int main()
{
    Duree chrono(10,30,59);
    Duree chrono2(10,20,56);
    Duree resultat;
    if(chrono == chrono2){
        cout << "les chronos sont �gaux"<<endl;
    }
    else {
        cout << "les chronos ne sont pas �gaux"<<endl;
    }
    if(!(chrono != chrono2)){
        cout << "les chronos sont �gaux"<<endl;
    }
    else {
        cout << "les chronos ne sont pas �gaux"<<endl;
    }
    if(chrono>chrono2){
        cout << "chrono est sup � chrono2"<<endl;
    }
    else{
         cout << "chrono est inferieur � chrono2"<<endl;
    }


    cout<<chrono;
    cout<<chrono2;
    cout<<resultat;
    resultat= chrono2+chrono;
    cout<<resultat;
    resultat=resultat-chrono;
    cout<<resultat;
    cin >>resultat;
    cout<<resultat;

    return 0;
}
