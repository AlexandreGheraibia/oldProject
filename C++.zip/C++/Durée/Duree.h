#ifndef DUREE_H_INCLUDED
#define DUREE_H_INCLUDED
#include <iostream>
#include "Duree.h"


class Duree

{

    public:
    Duree(int heures = 0, int minutes = 0, int secondes = 0);
    Duree(Duree const &autre);
   // Duree addtion(Duree const &b)const;
    Duree& operator+=(Duree const& b);
    Duree& operator-=(Duree const& b);

    private:
    int m_heures;
    int m_minutes;
    int m_secondes;


    friend std::ostream& operator <<(std::ostream &flux, Duree const& durees );
    friend std::istream& operator >>(std::istream &flux,Duree &duree);
    friend bool operator ==(Duree const & a,Duree const &b);
    friend bool operator !=(Duree const &a,Duree const &b);
    friend bool operator >(Duree const& a,Duree const &b);
    friend bool operator <=(Duree const& a,Duree const &b);
    friend bool operator >(Duree const& a,Duree const &b);
    friend bool operator >=(Duree const& a,Duree const &b);
    friend Duree operator +(Duree const&  a,Duree const &b);
    friend Duree operator -(Duree const &  a,Duree const &b);

};
//Surcharge des operateurss de comparaison


#endif // DUREE_H_INCLUDED
