#include "Duree.h"
#include <iostream>


using namespace std;

bool operator ==(Duree const & a,Duree const &b){
    return a.m_heures==b.m_heures&&a.m_minutes==b.m_minutes&&a.m_secondes==b.m_secondes;

}
bool operator !=(Duree const &a,Duree const &b){
	return !(a==b);
}
bool operator >(Duree const& a,Duree const &b){
      if(a.m_heures==b.m_heures)
     {
         if(a.m_minutes==b.m_minutes){
                return a.m_secondes>b.m_secondes;

         }
         else{
            return a.m_minutes>b.m_minutes;
         }
     }
     else{
            return a.m_heures>b.m_heures;
     }
}
bool operator <=(Duree const& a,Duree const &b){
    return !(a>b);
}
bool operator <(Duree const& a,Duree const &b){
    return !(a>b)&&!(a==b);
}
bool operator >=(Duree const &a,Duree const &b){
    return !(a<b);
}

Duree operator +(Duree const &  a,Duree const &b){
    Duree tampon(a);
    tampon+=b;
   return tampon;
}

Duree operator -(Duree const &  a,Duree const &b){
    Duree tampon(a);
    tampon-=b;
   return tampon;
}

Duree operator+(Duree const& duree, int secondes){
    Duree tampon(0,0,secondes);    //On utilise le constructeur de copie de la classe Duree !
    tampon +=duree ;     //On appelle la m�thode d'addition qui modifie l'objet 'copie'
    return tampon;          //Et on renvoie le r�sultat

}

ostream &operator<<(ostream &flux, Duree const& duree )
{
     flux << "heures: "<<duree.m_heures<<" minutes: "<<duree.m_minutes<<" secondes: "<<duree.m_secondes<<endl;
    return flux;

}
istream &operator >>(istream &flux,Duree &duree){
    flux >>duree.m_heures;
    flux >>duree.m_minutes;
    flux >>duree.m_secondes;
    duree.m_minutes+=duree.m_secondes/60;
    duree.m_secondes%=60;
    duree.m_heures+=duree.m_minutes/60;
    duree.m_minutes%=60;
    return flux;
}

Duree& Duree::operator+=(Duree const& b){
    m_heures+=b.m_heures+(m_minutes+b.m_minutes)/60;
    m_minutes=(m_minutes+b.m_minutes)%60+(m_secondes+b.m_secondes)/60;
    m_secondes=(m_secondes+b.m_secondes)%60;
    return *this;
}

Duree& Duree::operator-=(Duree const& b){
    m_secondes=(m_heures-b.m_heures)*3600+60*(m_minutes-b.m_minutes)+(m_secondes-b.m_secondes);
    m_heures=m_secondes/3600;
    m_secondes%=3600;
    m_minutes=m_secondes/60;
    m_secondes%=60;
    return *this;
}

Duree::Duree(Duree const &autre):m_heures(autre.m_heures),m_minutes(autre.m_minutes),m_secondes(autre.m_secondes) {}
/*
Duree Duree::addtion(Duree const &b) const{
    Duree tampon;
    tampon.m_heures=m_heures+b.m_heures+(m_minutes+b.m_minutes)/60;
    tampon.m_minutes=(m_minutes+b.m_minutes)%60+(m_secondes+b.m_secondes)/60;
    tampon.m_secondes=(m_secondes+b.m_secondes)%60;
    return tampon;

}*/

Duree::Duree(int heures, int minutes, int secondes){
        m_heures=heures+minutes/60;
        m_minutes=minutes%60+secondes/60;
        m_secondes=secondes%60;
}

