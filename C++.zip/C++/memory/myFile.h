#ifndef MYFILE_H_INCLUDED
#define MYFILE_H_INCLUDED
#include <fstream>
#include <iostream>
#include <string>

void EcrireDansFichier(std::string const& nomFichier,std::string const& donnees);
std::ofstream& ouvrirfileEcriture(std::string const& nomFichier);
void lireLeFichier(std::string const& nomFichier);
#endif // MYFILE_H_INCLUDED
