#include <string>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <vector>


using namespace std;
/*
Brief: formate la chaine de caract�res mots en une chaine de caract�res �quivalente en minuscule.
Param:une chaine de caract�res
return: une chaine de caract�res
*/
string passToLower(string mots)
 {  unsigned int i(0);
    while (i!=mots.size())
    {
        mots[i]=tolower(mots[i]);
        i++;
    }
    return mots;
}
/*
Brief: choisirElementDico pioche une chaine de caract�res dans le vecteur de string r�f�renc� par dico.
La chaine pioch�e est retir�e de dico et est renvoy�e par la fonction choisirElementDico.
Param: dico un vecteur de chaine de caract�res.
Return: string.
*/
string choisirElementDico(vector<string>& dico){
    string tmp;
    int choose;
    srand(time(0));
    choose=rand()%dico.size();
    tmp=dico[choose];
    dico.erase(dico.begin()+choose);
    return tmp;
}

/*
Brief:remplirDico remplit le vecteur de string r�f�renc� par dico avec les mots contenus dans
le fichier sp�cifi� par la r�f�rence nomFichier
Param:une r�f�rence sur une constante de chaine de caract�res et une r�f�rence sur un vecteur de string
Return: rien
*/

void remplirDico(string const& nomFichier,vector<string>& dico){

    ifstream monFile(nomFichier.c_str());
    if(monFile){
       string ligne;
        while (getline(monFile,ligne))
        {
            dico.push_back(passToLower(ligne));
        }
    }
    else{
         cout<<"l'ouverture du fichier "<< nomFichier.c_str()<<" a echoue";
    }
}


int main()
{   string secretWord,tryWord,result,nomFichier("dico.txt");
    vector<string> dico;
    char newTry;
    int choose,attempt;

	do{
        result="";
        tryWord="";
        newTry='n';
        secretWord="";
        attempt=5;
        if(dico.size()==0)
        {
            remplirDico(nomFichier,dico);
        }
        /*do{
            cout <<"Enter the word to find"<<endl;
            cin >> secretWord;
        }
         while(secretWord.size()==0);
         system("cls");
        */
        secretWord=choisirElementDico(dico);

        //initilisation de la graine

        tryWord=secretWord;
        while(tryWord.size()>0)
        {
            srand(time(0));
            choose=rand()%tryWord.size();
            result+=tryWord[choose];

            tryWord.erase(choose, 1);
        }

        cout << "Letter of the word to find"<<endl;
        cout << result<<endl;
        do{
            if(attempt!=5){
               cout <<"Attempt remaining : "<<attempt<<endl;
            }
            else
                cout <<"Enter the word you think is the solution"<<endl;

            cin >> tryWord;
            tryWord=passToLower(tryWord);
            attempt--;

        }while(attempt>0 && secretWord.compare(tryWord)!=0);
        if(attempt>0){
            cout<<"Well done"<<endl;
        }
        else{
            cout <<"The word was : "<<secretWord<<endl<<"Next time!"<<endl;
        }
        cout <<"Do you want play again? Y/N"<<endl;
        cin >>newTry;
    }while(newTry=='y'||newTry=='Y');

    return 0;

}
