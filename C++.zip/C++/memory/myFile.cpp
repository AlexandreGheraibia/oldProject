#include "myFile.h"
/*
std::ofstream& ouvrirfileEcriture(std::string const& nomFichier){
     static std::ofstream  monFlux(nomFichier.c_str(),std::ios::app);
     if(!monFlux)
      std::cout<<"l'ouverture du fichier "<< nomFichier.c_str()<<"a �chou�";
     return monFlux;
}
void lireLeFichier(std::string const& nomFichier){
    std::ifstream monFile(nomFichier.c_str());
    if(monFile){
       std::string ligne;
        while (std::getline(monFile,ligne))
        {
            std::cout<<ligne<<std::endl;
        }
    }
    else{
         std::cout<<"l'ouverture du fichier "<< nomFichier.c_str()<<"a �chou�";
    }
}


void EcrireDansFichier(std::string const& nomFichier,std::string const& donnees){
   std::ofstream monFlux(nomFichier.c_str(),std::ios::app);
     if(monFlux){
        monFlux<<donnees<<std::endl;
     }
     else{
         std::cout<<"l'ouverture du fichier "<< nomFichier.c_str()<<"a �chou�";
     }

}

//string const nomFichier("C:/Nanoc/scores.txt");
*/
