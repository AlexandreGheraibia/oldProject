#include "table.h"
/*
brief: initialize pTab with the first natural integer under the size of pTab
parameter: vector pTab
return: nothing
*/
void initialize(std::vector <int>& pTab){
for(unsigned int i(0);i<pTab.size();i++)
    pTab[i]=i;
}
/*
brief: exchange the values between two elements which respectively have for index i and j in the vector tab
parameter: reference vector tab, integer i and integer j
return: nothing
*/

void exchangeTab(std::vector<int>& tab,int i,int j){
    int temporary(tab[i]);
    tab[i]=tab[j];
    tab[j]=temporary;
    return ;
}
/*
brief: Display the sequence of all elements of contained in the vector which have for reference pTab
parameter: reference on the vector pTab
return: nothing
*/

void display(std::vector <int>const & pTab){
 for(unsigned int i(0);i<pTab.size();i++)
    {
        std::cout <<pTab[i]<<" ";
    }
     std::cout <<  std::endl;
}
