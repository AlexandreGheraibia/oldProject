#ifndef TABLE_H_INCLUDED
#include <iostream>
#include <vector>
#define TABLE_H_INCLUDED


void exchangeTab(std::vector<int>& tab,int i=0,int j=1);
/*
*/
void display(std::vector<int> const & pTab);

void initialize(std::vector <int>& pTab);

#endif // TABLE_H_INCLUDED
