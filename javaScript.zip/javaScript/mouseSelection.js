/*
display the  "wrap box" of an object (I must change the name) 
and according to the mode selected change the camera target to the object selected.
The target by default is the center of the scene.

*/
function selection_item(objet){
			if(objet){
				
				if(selected==null) 
				{
				 selected=objet;
				 selected.getObjectByName("cubewrap",true).visible=false;		
				
					var mode=0;
					switch(mode){
						case 1:
							controls.target=objet.position;
							
						case 0:
							var sel=objet.getObjectByName("cubewrap",true);
							if(sel.visible==false){
								sel.visible=true;
							
							}
						break;
						
					}	
					
				}
			}
			else{
					if(selected) {
								selected.getObjectByName("cubewrap",true).visible=false;
								selected=null;
								
					}
			}
}

	
/*
allows to move an object with the mouse through the 3d scene 
*/			
function onDocumentMoveDown( event ){
			if(isLeftDown==true&&selected!=null){
					event.preventDefault();//prevent the default behavior of the event mouse
					var x=event.clientX-this.offsetLeft+window.pageXOffset;
					var y=event.clientY-this.offsetTop+window.pageYOffset;
					this.addEventListener("mousemove", onDocumentMoveDown, false );
					this.addEventListener("mouseup", onDocumentMouseUp, false );
					x=( x  ) * 2-screenWidth;
					y= - (y ) * 2 +screenHeight;
					d= camera.position.distanceTo(origine);
					var v=new THREE.Vector3(x,y*camera.aspect, -1)//-d distance du plan de  projection � la camera/distance between the camera and the projection plan
					v.unproject( camera );
					v.sub(camera.position);
					selected.position.set(v.x,v.y,v.z);
					selected.position.multiplyScalar(d/screenWidth);
					selected.centre();
			
			}

}
/*
drop the element selected and deselect it

*/
function onDocumentMouseUp( event ){
		this.removeEventListener("mousemove", onDocumentMoveDown, false );
		this.removeEventListener("mouseup", onDocumentMouseUp, false );
		selection_item(null);
		isLeftDown=!isLeftDown;
}
/*
allow to select an object with the mouse in the 3d scene.
transpose the window coordonnees(x,y) to the 3d scene (x,y,z) (I must retry to add a depth correction)

*/
function onDocumentMouseDown( event ) {
		if(isLeftDown!=true)
		switch(event.keyCode || event.which){
			case 1 :
				isLeftDown=true;
				event.preventDefault();
				var screenHeight=this.height;
				var screenWidth=this.width;
				var x=event.clientX-this.offsetLeft+window.pageXOffset;
				var y=event.clientY-this.offsetTop+window.pageYOffset;
				this.addEventListener("mousemove", onDocumentMoveDown, false );
				this.addEventListener("mouseup", onDocumentMouseUp, false );
				vector=new THREE.Vector3(( x/ screenWidth ) * 2-1, - (y/ screenHeight ) * 2 +1, -1 );//d distance camera plan de projection
				vector.unproject( camera );//on projecte le vecteur dans l'espace 3d de la cam 
				raycaster =new THREE.Raycaster( camera.position, vector.sub( camera.position ).normalize() );//on lance un rayon en partantde la cam dans la direction dupoint s
				var intersects = raycaster.intersectObjects( objects );//on calcul l'intersection entre les objets qui sont rang�s dans l'ordre
				//d'intersection
				if ( intersects.length > 0 ) {
					var intersect = intersects[ 0 ];
					selection_item(intersect.object);
				}else{
					selection_item(null);
				}
			break;
		}
}
