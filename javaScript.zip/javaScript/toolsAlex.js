
//main
var screenWidth,screenHeight;
//les controleurs 
var controls,stats,gui,guicontrols;
//elements de scene/scene element
var camera, scene, renderer, axes;
//light of the scene
var ambientLight,directionalLight,spotLights=[],pointLight;
//elements objet scene
var skinnedMesh, terrain, box2,animation=[],anim2=[], helper ;
//tableau des objets selectionnable et selecteur
//var objects=[skinnedMesh, terrain,box2];
var myTimer=null;
var origine=new THREE.Vector3(0,0,0);
var play=false,usetext=false;
var timeAccu=0,triggerTime=3;
var clock = new THREE.Clock();
//particule engine
var engine=null;
var objects=[];
var texture=null;
//mouse
var isLeftDown=false;
var selected=null;

//sound
var  context=null;
var canvasWidth=null,canvasHeight=null,canvasCtx=null;
var analyser=null,bufferLength=null,dataArray=[],audioBuffer=[];
var bufferSound=[];
//miscellaneous more crossover between many thing

/***********************************************/
function progressSoundLoad(){

}




/**********************************************/
function handleResize() {
    camera.aspect = screenWidth / screenHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(screenWidth, screenHeight);
}
/**********************************************/


THREE.Object3D.prototype.calculCentre = function()
{	this.geometry.computeBoundingBox();
	var max=this.geometry.boundingBox.max;
	var min=this.geometry.boundingBox.min;
	this.w=Math.abs(max.x-min.x);
	this.h=Math.abs( max.y-min.y);
	this.d=Math.abs(max.z-min.z );
	this.cx=(max.x+min.x)/2.0;
	this.cy=(max.y+min.y)/2.0;
	this.cz=(max.z+min.z)/2.0;
   
};

THREE.Object3D.prototype.centre = function()
{	this.position.x-=this.cx;
	this.position.y-=this.cy;
	this.position.z-=this.cz;
   
};
function add_Box(obj){
	obj.calculCentre();
	geometry = new THREE.BoxGeometry( obj.w,obj.h,obj.d);
    material = new THREE.MeshBasicMaterial( { color: 0x00ff00, wireframe: true } );
	box = new THREE.Mesh(geometry,material );
	box.position.set(obj.cx,obj.cy,obj.cz);
	box.visible=false;
	box.name="cubewrap";
	obj.add(box);
}
function resetLight(){

spotLights[0].color={r:1,g:0,b:0};
spotLights[1].color={r:0,g:1,b:0};
spotLights[2].color={r:0,g:0,b:1};


}
function restartEngine(parameters)
{   
	engine = new ParticleEngine();
	engine.setValues( parameters );
	engine.initialize(0.1);
}