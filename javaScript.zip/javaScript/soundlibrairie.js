
/*
create a audio context for decoding and play the sound
and initialize canvas
*/
function init_soundContext(){
			if( 'webkitAudioContext' in window ) context = new webkitAudioContext();//cree un contexte audio temporaire  
			else if( 'AudioContext' in window ) context = new AudioContext();
			if( !context ) {
				console.log( 'ERROR: No AudioContext available. Try Chrome, Safari of Firefox Nightly.' );
			}
			else{	
					/*init size*/
					canvasWidth=document.getElementById('mycanvas').width;
					canvasHeight=document.getElementById('mycanvas').height;
					canvasCtx=document.getElementById("mycanvas").getContext("2d");
					analyser = context.createAnalyser();
					analyser.fftSize = 2048;//fast fourrier transform which represent the range of the wave?
					bufferLength = analyser.frequencyBinCount;//half of fourrier
					dataArray = new Uint8Array(bufferLength);
					canvasCtx.strokeStyle ='rgb(255,255,255)';
					canvasCtx.lineWidth = 1;
					resetCanvas();
				}
}
		
/*
we wait before the sort for to be sure to let the time at the decoding to be finish 

*/
function triSound(){
		if(5>bufferSound.length){
			if(myTimer) clearTimeout(myTimer);
			myTimer=setTimeout("triSound()",10);
		}
		else{
			tri_Sound();
		}
		
}
/*
sort the bufferSound, we sort it because the load and decoding are asynchronous and not deal with the same way by browser
*/		
function tri_Sound(){
var i=0,j,l,tmp;
clearTimeout(myTimer);
l=bufferSound.length;

while(i<l){
	j=i+1;
	while(j<l-1){
		if(bufferSound[i].length>bufferSound[j].length){
		tmp=bufferSound[j];
		bufferSound[j]=bufferSound[i];
		bufferSound[i]=tmp;
		}
		j++;
	}
i++;
}

}	

/*
load and splice the sound file then fill the bufferSound for we can use.   
*/
function load(filename,updateProgress){
			/*chargement asynchrone*/
			if(context){
			var request = new XMLHttpRequest();//à lire
			request.addEventListener("load",triSound , false);
		//	request.onprogress =updateProgress;
			request.open( 'GET', filename, true );
			request.responseType = 'arraybuffer';
			request.onload = function() {
				var length=null,tmpSound=null,offset = 0,i=0, bb = new DataView(request.response );
					
					while( offset < bb.byteLength ) {
						j=bb.getUint32(offset, true);//not use and unusable the cause of the asynchronous nature of the httprequest 
						length=bb.getUint32( offset+4, true );
						offset += 8;
						tmpSound= new Uint8Array(length);
						tmpSound.set(new Uint8Array(request.response,offset, length ));
						context.decodeAudioData(tmpSound.buffer , function( dataRes ) {
						bufferSound[i]=dataRes;
						i++;
						},function(e){"Error with decoding audio data" + e.err});
						offset += length;
					}
				}
				request.send();
			}
}

function onError(e) {
  alert("An error " + e.target.status + " it's occurred while the sound File was downloaded ");
}

/*
play the sound at the index i with the rate n
and get a pointer over the sound play for we can stop it when we want. 
*/		
function playSound(i,n,activehandler){
		
					if(context){
						
						if(audioBuffer&&audioBuffer[i]!==undefined&&audioBuffer[i]!==null){
							audioBuffer[i].stop();
						}
							var audioSource=context.createBufferSource();
							audioBuffer[i]=audioSource;
							if(n>-1){
								audioSource.playbackRate.value=2-n/10;
							}
							if(i==4){
							audioSource.connect(analyser);
							}
							audioSource.connect(context.destination);
							audioSource.buffer=bufferSound[i];
							audioSource.start(0);
							if(activehandler)
							audioSource.onended = endedhandler;
						
					}
					
				
}

function endedhandler(){
if(play) play=false;

}
function stopSound(i){
		if(audioBuffer&&audioBuffer[i]){
		audioBuffer[i].stop();
		audioBuffer[i]=null;
		}
}

function resetCanvas(){
	canvasCtx.clearRect(0, 0, canvasWidth, canvasHeight);
	canvasCtx.beginPath();
	canvasCtx.moveTo(0, canvasHeight/2);
	canvasCtx.lineTo(canvasWidth, canvasHeight/2);
	canvasCtx.stroke();
}




// draw an oscilloscope of the current audio source
//http://www.w3.org/TR/2013/WD-webaudio-20131010/
     
function draw(use) {
		analyser.getByteTimeDomainData(dataArray);
		canvasCtx.clearRect(0, 0, canvasWidth, canvasHeight);
		canvasCtx.beginPath();
	  //découpe la largeur du canevas en longueur d'onde
      var sliceWidth = canvasWidth / bufferLength;
	  var moyenne=0;
      var x = 0;
	  //parcours le buffer de données
	  //traverse the data buffer
      for(var i = 0; i < bufferLength; i++) {
        var v = dataArray[i] / 128.0;
		var y = v * canvasHeight/2;
        if(i === 0) {
          canvasCtx.moveTo(x, y);
        } else {
          canvasCtx.lineTo(x, y);
        }
		//spotLight.color
		if(use) moyenne+=v;
        x += sliceWidth;
      }
	  if(use){
	  moyenne/=bufferLength;
	  moyenne%=1;
	  spotLights[0].color.r=moyenne;
	  spotLights[1].color.g=moyenne/2;
	  spotLights[2].color.b=1-moyenne;
	  }
      canvasCtx.stroke();
    }

   
