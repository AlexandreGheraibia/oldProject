
/** @author Alexandre Gheraibia
 **************
 * TP lesson 2*
 **************
 * La class main
 * Créee un objet Garage dans lequel on peut ajouter des objets
 * Vehicules et les sauvegarder. 
 ***/
import moteur.*;
import option.BarreDeToit;
import option.Climatisation;
import option.GPS;
import option.SiegeChauffant;
import option.VitreElectrique;
import vehicule.Vehicule;

import java.io.IOException;

import fr.alex311.garage.*;

public class Main {

	public static void main(String[] args) throws RequisMoteur, ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		Vehicule lag1, lag2,A300B_1, d4_2;
		Garage gdz=new Garage(); 
		 System.out.println(gdz); 
		 lag1 = new Lagouna();
		 lag1.setMoteur(new MoteurEssence("150 Chevaux", 10256d));
		
	   	 lag1.addOption(new GPS());
	   	 lag1.addOption(new SiegeChauffant());
	   	 lag1.addOption(new VitreElectrique());
	   	// System.out.println(lag1);
	   	 lag2 = new Lagouna(new MoteurDiesel("500 Hdi", 456987d));
	   	//System.out.println(lag2);
	   	 A300B_1 = new A300B();
	   	 A300B_1.setMoteur(new MoteurHybride("ESSENCE/Electrique", 12345.95d));
	   	 A300B_1.addOption(new VitreElectrique());
	   	 A300B_1.addOption(new BarreDeToit());
	   	//System.out.println( A300B_1);
	   	 d4_2 = new D4();
	   	 d4_2.setMoteur(new MoteurElectrique("100 KW", 1224d));
	   	 d4_2.addOption(new SiegeChauffant());
	   	 d4_2.addOption(new BarreDeToit());
	   	 d4_2.addOption(new Climatisation());
	   	 d4_2.addOption(new GPS());
	   	 d4_2.addOption(new VitreElectrique());
	   	// System.out.println( d4_2);
	   	 gdz.add(lag1);
	   	 gdz.add(lag2);
	   	 gdz.add(A300B_1);
	   	 gdz.add( d4_2);
	  
	   	
	}

}
