package moteur;

/**la classe MoteurElectrique hérite de la classe Moteur
 * elle redéfinit le constructeur de Moteur 
 * pour creer un objet de type TypeMoteur.ELECTRIQUE 
 */
@SuppressWarnings("serial")
public class MoteurElectrique extends Moteur {

	public MoteurElectrique(String cylindre, double prix) throws RequisMoteur {
		super(cylindre, prix);
		super.type=TypeMoteur.ELECTRIQUE;
		// TODO Auto-generated constructor stub
	}

	

}
