package moteur;

/**la classe MoteurEssence hérite de la classe Moteur
 * elle redéfinit le constructeur de Moteur 
 * pour creer un objet de type TypeMoteur.ESSENCE 
 */
@SuppressWarnings("serial")
public class MoteurEssence extends Moteur{

	public MoteurEssence(String cylindre, double prix) throws RequisMoteur {
		super(cylindre, prix);
		// TODO Auto-generated constructor stub
		this.type=TypeMoteur.ESSENCE;
	}

	

}
