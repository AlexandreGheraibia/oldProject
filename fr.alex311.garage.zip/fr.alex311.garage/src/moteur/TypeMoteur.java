package moteur;
/**
 * enum TypeMoteur définit une énumération des moteurs selon leurs carburants
 * et leur associe un objet string contenant le nom de leur carburant. 
 */
 
public enum TypeMoteur {
	DIESEL("DIESEL"),
	ESSENCE("ESSENCE"),
	HYBRIDE("HYBRIDE"),
	ELECTRIQUE("ELECTRIQUE");
	private String energie="";
	
	//Constructeur
	TypeMoteur(String name){
		this.energie = name;
	  }
	
	  public String toString(){
	    return "Moteur "+ energie;
	  }

}
