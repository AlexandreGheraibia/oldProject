package moteur;

import java.io.Serializable;
/**l'abstract Moteur implémente sérialisable
 * elle est la superclasse qui définit les champs et les méthodes
 * d'un moteur. Elle est serialisable pour permettre la sauvegarde
 * des objets Vehicule. 
 */
 
@SuppressWarnings("serial")
public abstract class Moteur  implements Serializable{
	protected TypeMoteur type=null;
	private String cylindre="";
	private double prix=0;
	/**Constructeur Moteur 
	 * Prend en paramétre un string Cylindre et un double prix
	 * et émet une exception RequiMoteur si le prix est négatif, ou si
	 * le paramétre cylindre est une chaine vide.
	 * Il initialise les champs privé prix et cylindre
	 */
	 
	Moteur(String cylindre, double prix) throws RequisMoteur{
		if(prix<=0||cylindre=="") {
			 throw new RequisMoteur ();
		}
		else {
		this.prix=prix;
		this.cylindre=cylindre;
		}
	}
	/**
	 * toString renvoie sous forme d'un objet String
	 * les champs privés cylindre et prix
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.type+" "+this.cylindre+" ("+this.prix+")";
	}
	/**
	 * getPrix est un accesseur qui renvoie 
	 * le champs privé prix de type double
	 */
	public double getPrix() {
		return prix;
	}
}
