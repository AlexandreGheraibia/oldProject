package moteur;

/**la classe MoteurDiesel hérite de la classe Moteur
 * elle redéfinit le constructeur de Moteur 
 * pour creer un objet de type TypeMoteur.Diesel 
 */
@SuppressWarnings("serial")
public class MoteurDiesel extends Moteur {

	public MoteurDiesel(String cylindre, double prix) throws RequisMoteur {
		super(cylindre, prix);
		// TODO Auto-generated constructor stub
		super.type=TypeMoteur.DIESEL;
	}

	

}
