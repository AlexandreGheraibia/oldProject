package moteur;

/**
 * La classe RequisMoteur hérite de la classe exception.
 * Elle permet de traiter les exceptions du constructeur 
 * de la classe Moteur 
 * */
@SuppressWarnings("serial")
public class RequisMoteur extends Exception {
	
	public RequisMoteur() {
		System.err.println("un moteur est défini par un prix positif et un type");
		
	}
}
