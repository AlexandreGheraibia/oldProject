package moteur;

/**la classe MoteurHybride hérite de la classe Moteur
 * elle redéfinit le constructeur de Moteur 
 * pour creer un objet de type TypeMoteur.HYBRIDE 
 */
@SuppressWarnings("serial")
public class MoteurHybride extends Moteur{

	public MoteurHybride(String cylindre, double prix) throws RequisMoteur {
		super(cylindre, prix);
		// TODO Auto-generated constructor stub
		super.type=TypeMoteur.HYBRIDE;
	}


}
