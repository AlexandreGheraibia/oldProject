package vehicule;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import moteur.Moteur;
import option.Option;
/**
 * la classe Vehicule implémente l'interface Serializable
 * elle définit les champs :
 * prix un double
 * nom un String
 * option un List<option>
 * un nomMarque une Marque
 * et un moteur
 * ce qui représente le nom, la marque , le prix, les options et le moteur
 * d'un véhicule.Elle est sérialisable afin d'être sauvegardé par un objet Garage.
 */
@SuppressWarnings("serial")
public abstract class Vehicule implements Serializable {

 private double prix;
 protected String nom;
 private List<Option> options;
 protected Marque nomMarque;
 private Moteur moteur;
 
 /**Constructeur Vehicule
  * initialise le prix, le nom est la liste d'options 
  * d'un véhicule
  * */
 public Vehicule(){
	 prix=0;
	 nom="";
	 options=new ArrayList<Option>();
	 
 }
 public	 Vehicule(Moteur moteur){
		this();
		this.setMoteur(moteur);
	}
 /**Méthode toString()
  * renvoie la liste des options et leur prix sous la forme d'un
  * objet string
  * */
 public String toString() {
		// TODO Auto-generated method stub
	 String result="[";
	 if(options.size()!=0) {
	
	    for(Option opt : options)
	    {
	    	result+=opt+" "+opt.getPrix()+"€, ";
	    }
	    result=result.substring(0, result.length()-2);
		
	 }
	 else {
		 result="[Aucune option";
	 }
	 return "voiture "+nomMarque+" : "+nom+" "+moteur
				+result
				+"] d'une valeur totale de "+prix+"€";
	
 }
 /**Méthode setMoteur(Moteur moteur)
  * elle prend en paramétre un objet moteur
  * elle définit le moteuret réévalue le prix d'un véhicule
  * en fonction du prix de son moteur.
  * */
 public void setMoteur(Moteur moteur) {
	 this.moteur=moteur;
	 prix+=moteur.getPrix();
 }
 /**Méthode addOption(Option opt)
  * elle prend en paramétre un objet Option
  * elle ajoute une option et réévalue le prix d'un véhicule 
  * en fonction du prix de sa nouvelle option.
  * */
 public void addOption(Option opt) {
	 options.add(opt);
	 this.prix+=opt.getPrix();
 }
 /**Accesseur getMarque()
  *  renvoie un objet string représentant le nom de la marque 
  *  d'un vehicule.  
  * */
 public Marque getMarque() {
	 return nomMarque;
 }
 /**Accesseur getOptions()
  *  renvoie un List<Option> représentant les différentes options
  *  d'un vehicule.  
  * */
 public List<Option>getOptions(){
	return options;
 }
 /**Accesseur getPrix()
  *  renvoie un double représentant le prix total
  *  d'un véhicule
  * */
 public double getPrix() {
	 return prix;
 }
}
