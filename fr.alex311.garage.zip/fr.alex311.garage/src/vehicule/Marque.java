package vehicule;

/**
 * enum Marque définit une énumération sur les marques possibles de 
 * véhicules et associe une chaine de caractére représentant le nom des marques
 */
 
public enum Marque {
	PEUGEOT("PIGEOT"),
	RENAULT("RENO"),
	CITROEN("TROEN") ;
	private String contreFacon="";
	
	Marque(String marque){
		contreFacon=marque;
	}
	
	 public String toString(){
		    return  contreFacon;
	}

}
