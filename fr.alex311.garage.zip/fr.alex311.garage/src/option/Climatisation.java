package option;

import java.io.Serializable;
/**
 * Climatisation est une classe qui implémente les interfaces Option et Serializable.
 * Elle définit un objet Climatisation  en redéfinissant les méthodes getPrix et toString:
 * cette classe est sérialisable pour permettre la sérialistion de la classe Véhicule
 *  
 */
@SuppressWarnings("serial")
public class Climatisation implements Option,Serializable {
	
	@Override
	public double getPrix() {
		// TODO Auto-generated method stub
		return 347.3d;
	}
	public String toString() {
		return "Climatisation";
	}
}
