package option;

import java.io.Serializable;
/**
 * BarreDeToit est une classe qui implémente les interfaces Option et Serializable.
 * Elle définit un objet BarreDeToit  en redéfinissant les méthodes getPrix et toString:
 * cette classe est sérialisable pour permettre la sérialistion de la classe Véhicule
 *  
 */
@SuppressWarnings("serial")
public class BarreDeToit implements Option,Serializable {
    
	@Override
	public double getPrix() {
		// TODO Auto-generated method stub
		return 29.90d;
	}
	public String toString() {
		return "Barre de toit";
	}
}
