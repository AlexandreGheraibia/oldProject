package option;
/**
 * L'interface Option définit les méthodes des différentes options possible de la classe Véhicule  
 **/

public interface Option  {
	/** getFrix() 
	 * renvoie le prix de type double d'un objet Option 
	 * */
	
	public double getPrix();
	
}
