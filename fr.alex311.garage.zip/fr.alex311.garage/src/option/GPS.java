package option;

import java.io.Serializable;
/**
 *  GPS est une classe qui implémente les interfaces Option et Serializable.
 * Elle définit un objet  GPS  en redéfinissant les méthodes getPrix et toString:
 * cette classe est sérialisable pour permettre la sérialistion de la classe Véhicule
 *  
 */
@SuppressWarnings("serial")
public class GPS implements Option,Serializable {

	@Override
	public double getPrix() {
		// TODO Auto-generated method stub 
		return 113.5d;
	}
	public String toString() {
		return "GPS";
	}
}
