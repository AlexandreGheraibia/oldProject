package option;

import java.io.Serializable;
/**
 *  SiegeChauffant est une classe qui implémente les interfaces Option et Serializable.
 * Elle définit un objet  SiegeChauffant  en redéfinissant les méthodes getPrix et toString:
 * cette classe est sérialisable pour permettre la sérialistion de la classe Véhicule
 *  
 */
@SuppressWarnings("serial")
public class SiegeChauffant implements Option,Serializable{
	@Override
	public double getPrix() {
		// TODO Auto-generated method stub
		return 562.9d;
	}
	public String toString() {
		return "Siège Chauffant";
	}
}
