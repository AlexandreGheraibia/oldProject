package option;

import java.io.Serializable;
/** 
 *  VitreElectrique est une classe qui implémente les interfaces Option et Serializable.
 * Elle définit un objet  VitreElectrique  en redéfinissant les méthodes getPrix et toString:
 * cette classe est sérialisable pour permettre la sérialistion de la classe Véhicule
 *  
 */
@SuppressWarnings("serial")
public class VitreElectrique implements Option,Serializable {
	@Override
	public double getPrix() {
		// TODO Auto-generated method stub
		return 212.35d;
	}
	public String toString() {
		return "Vitre électrique";
	}
}
