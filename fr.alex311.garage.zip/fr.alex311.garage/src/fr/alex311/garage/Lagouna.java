package fr.alex311.garage;

import java.io.IOException;

import moteur.Moteur;
import vehicule.Marque;
import vehicule.Vehicule;

/**
 * Lagouna est une classe héritière de la classe Véhicule.
 * Elle définit un objet LAgouna en redéfinissant grâce à son constructeur les champs:
 * nom de type string égal à "Lagouna"
 * nomMarque de type Marque égal à RENAULT
 *  
 */

@SuppressWarnings("serial")
public class Lagouna extends Vehicule{

public Lagouna()throws IOException,ClassNotFoundException {
		this.nom="Lagouna";
		this.nomMarque=Marque.RENAULT;
		// TODO Auto-generated constructor stub
	}
public Lagouna(Moteur moteur) throws IOException,ClassNotFoundException{
	super(moteur);
	this.nom="Lagouna";
	this.nomMarque=Marque.RENAULT;
	
}
}
