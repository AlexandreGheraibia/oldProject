/**
 * la classe garage permet de créer des garages contenant une liste de véhicules sérialisable 
 * et d'afficher cette liste
 */
 
package fr.alex311.garage;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import vehicule.Vehicule;

public class Garage {
	private List<Vehicule> voitures=null;
	/**
	 * Garage Constructeur de la classe Garage
	 * et initialise la liste de véhicule à partir 
	 * du fichier garage.txt
	 */
	public Garage() throws  IOException,ClassNotFoundException{
		voitures=new ArrayList<Vehicule>();
		read();
		
	}
	private void read() throws IOException, ClassNotFoundException {
		try( FileInputStream fis = new FileInputStream("garage.txt");
				  ObjectInputStream ois = new ObjectInputStream(fis)
				){
					voitures=extracted(ois);
		}
		 catch (FileNotFoundException e) {
			 System.err.println("Garage inexistant !");
		      }
		catch(EOFException ex) {
			if(voitures.size()!=0) {
			 System.out.println("Chargement du garage accompli !");
			}
			else {
				System.out.println("Aucune voiture de sauvegardée !");
			}
			
		}
		
		
	}
	private List<Vehicule> extracted(ObjectInputStream ois) throws IOException, ClassNotFoundException {
		@SuppressWarnings("unchecked")
		List<Vehicule> list = (List<Vehicule>)ois.readObject();
		return list;
	}
	
	/**
	 * méthode toString
	 *renvoie la liste de véhicules sous la forme d'un objet String
	 */
	public String toString() {
		Iterator<Vehicule> itr = voitures.iterator();
		String result="****************\n"
					+ "*Garage du zero*\n"
					+ "****************";
		while(itr.hasNext()) {
			result+="\n"+itr.next();
			
		}
		return result;
	}
	/**
	 * méthode add
	 * ajoute un objet vehicule à liste de Vehicule d'un objet Garage
	 */
	public void add(Vehicule voit ) throws IOException  {
			voitures.add(voit);
			saveGarage(voitures);
	} 
	private void saveGarage(List<Vehicule> lVoit) throws IOException {
		try(FileOutputStream fos = new FileOutputStream("garage.txt");
				ObjectOutputStream oos = new ObjectOutputStream(fos)
				){
					
					oos.writeObject(lVoit);
		}
	}

	
}
