package fr.alex311.garage;

import moteur.Moteur;
import vehicule.Marque;
import vehicule.Vehicule;

/**
 * D4 est une classe héritière de la classe Véhicule.
 * Elle définit un objet  D4 en redéfinissant grâce à son constructeur les champs:
 * nom de type string égal à "D4"
 * nomMarque de type Marque égal à CITROEN
 *  
 */

@SuppressWarnings("serial")
public class D4 extends Vehicule{
	public D4() {
		super.nom="D4";
		super.nomMarque=Marque.CITROEN;
		// TODO Auto-generated constructor stub
	}
	public D4(Moteur moteur){
		super(moteur);
		this.nom="D4";
		this.nomMarque=Marque.CITROEN;
		
	}
}
