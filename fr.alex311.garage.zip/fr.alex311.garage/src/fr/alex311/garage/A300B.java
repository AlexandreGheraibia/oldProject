package fr.alex311.garage;

import moteur.Moteur;
import vehicule.Marque;
import vehicule.Vehicule;

/**
 * A300B est une classe héritière de la classe Véhicule
 * elle définit un objet A300B  en redéfinissant grâce à son constructeur les champs:
 * nom de type string égal à "A300B"
 * nomMarque de type Marque égal à PEUGEOT
 *  
 */
@SuppressWarnings("serial")
public class A300B extends Vehicule {
	public	A300B()  {
		this.nom="A300B";
		this.nomMarque=Marque.PEUGEOT;
		// TODO Auto-generated constructor stub
	}
	public	A300B(Moteur moteur){
		super(moteur);
		this.nom="A300B";
		this.nomMarque=Marque.PEUGEOT;
		
	}

}
